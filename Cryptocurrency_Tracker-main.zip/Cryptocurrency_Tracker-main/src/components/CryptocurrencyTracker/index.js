// Write your code here
import './index.css'
import CryptList from '../CryptocurrenciesList'

const CryptocurrencyTracker = () => (
  <div className="bgm5">
    <CryptList />
  </div>
)

export default CryptocurrencyTracker
