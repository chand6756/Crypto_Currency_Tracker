// Write your JS code here
import './index.css'

const Item = props => {
  const {details} = props
  const {currencyName, usdValue, euroValue, id, currencyLogo} = details
  return (
    <div className="bgm3">
      <div className="bgm4">
        <img src={currencyLogo} className="img" alt={currencyName} />
        <p className="para">{currencyName}</p>
      </div>
      <div className="bgm4">
        <p className="para">{usdValue}</p>
        <p className="para">{euroValue}</p>
      </div>
    </div>
  )
}

export default Item
