// Write your JS code here
import {Component} from 'react'
import './index.css'
import Loader from 'react-loader-spinner'
import 'react-loader-spinner/dist/loader/css/react-spinner-loader.css'
import Item from '../CryptocurrencyItem'

class CryptList extends Component {
  state = {listed: [], isLoading: true}

  componentDidMount() {
    this.get()
  }

  get = async () => {
    const response = await fetch(
      'https://apis.ccbp.in/crypto-currency-converter',
    )
    const data = await response.json()
    const update = data.map(each => ({
      currencyName: each.currency_name,
      usdValue: each.usd_value,
      euroValue: each.euro_value,
      id: each.id,
      currencyLogo: each.currency_logo,
    }))
    this.setState({listed: update, isLoading: false})
  }

  rendering = () => {
    const {listed, isLoading} = this.state
    return (
      <div className="bgm1">
        <h1 className="head">Cryptocurrency Tracker</h1>
        <img
          src="https://assets.ccbp.in/frontend/react-js/cryptocurrency-bg.png"
          alt="cryptocurrency"
        />
        <div className="list">
          <div className="inner">
            <p>Coin Type</p>
            <div className="inn">
              <p className="para">USD</p>
              <p className="para">EURO</p>
            </div>
          </div>
          <ul className="ul">
            {listed.map(each => (
              <Item details={each} key={each.id} />
            ))}
          </ul>
        </div>
      </div>
    )
  }

  render() {
    const {listed, isLoading} = this.state
    return (
      <div>
        {isLoading ? (
          <div data-testid="loader">
            <Loader
              type="TailSpin"
              color="white"
              height={50}
              width={50}
              className="load"
            />
          </div>
        ) : (
          this.rendering()
        )}
      </div>
    )
  }
}

export default CryptList
